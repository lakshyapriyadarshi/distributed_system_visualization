// chrome.storage.sync.set({ "disableButton": "0" }, function(){
// });




// chrome.storage.sync.clear()



//https://malicious-webpage-detection.herokuapp.com/https://malicious-webpage-detection.herokuapp.com/https://malicious-webpage-detection.herokuapp.com/

// chrome.tabs.onActivated.addListener( function(info)
// {
//     var tab = chrome.tabs.get(info.tabId, function(tab)
//     {
//       if (tab.url)
//       {
//          chrome.browserAction.setIcon({
//          path : "icon148.png"});
//          var url = tab.url;
//          var resp;
//          var obj;
//          var xhr;
//          chrome.storage.sync.get(url , function(data)
//          {
//            if (typeof data[url] === 'undefined')
//            {
//               obj = {};
//               xhr = new XMLHttpRequest();
//               xhr.open('GET', 'http://35.193.183.71/api?url_string=' + url);
//               xhr.onload = function()
//               {
//                   resp = JSON.parse(xhr.responseText);
//                   if (resp['Result'] === 'Safe' || resp['Result'] === 0)
//                   {
//                     chrome.browserAction.setIcon({
//                     path : "icon48.png" });
//                   }
//                   else
//                   {
//                      chrome.browserAction.setIcon({
//                       path : "icon248.png"}); 
//                   } 
//                   obj[url] = resp;
//                   chrome.storage.sync.set(obj, function(){});
//                   chrome.extension.onConnect.addListener(function(port) {
//                   port.postMessage(resp); });
//               }
//               xhr.send(); 
//            }
//            else
//              {
//                 chrome.storage.sync.get(url , function(data) {
//                   // alert(data[url]['Result']);
//                   chrome.extension.onConnect.addListener(function(port) {
//                   port.postMessage(data[url]); });
//                   if (data[url]['Result'] === 'Safe' || data[url]['Result'] === 0)
//                   {
//                     chrome.browserAction.setIcon({
//                     path : "icon48.png" });
//                   }
//                   else
//                   {
//                      chrome.browserAction.setIcon({
//                       path : "icon248.png"}); 
//                   } 
//                 });
//              }  
//          });
//        }
//      });
// });  


// chrome.tabs.onActivated.addListener( function(info)
// {
//     var tab = chrome.tabs.get(info.tabId, function(tab)
//     {
//       if (tab.url)
//       {
//          // chrome.browserAction.setIcon({
//          // path : "icon148.png"});
//          var url = tab.url;
//             var xhr = new XMLHttpRequest();
//             xhr.open('GET', 'http://35.193.183.71/api?url_string=' + url);
//             xhr.onload = function()
//             {
//                 var resp = JSON.parse(xhr.responseText);
//                 // if (resp['Result'] === 'Safe' || resp['Result'] === 0)
//                 // {
//                 //   chrome.browserAction.setIcon({
//                 //   path : "icon48.png" });
//                 // }
//                 // else
//                 // {
//                 //    chrome.browserAction.setIcon({
//                 //     path : "icon248.png"}); 
//                 // } 
//                 chrome.extension.onConnect.addListener(function(port) {
//                 port.postMessage(resp); });
//             }
//             xhr.send(); 
//          }
//        });
//    });



// chrome.tabs.onUpdated.addListener( function(tabId, changeInfo, tab)
// {

//       if (changeInfo.url)
//       {
//         alert(changeInfo.url);
//         chrome.browserAction.setIcon({
//         path : "icon148.png"});
//          var url = changeInfo.url;
//          chrome.storage.sync.get(url , function(data)
//          {
//            if (typeof data[url] === 'undefined')
//            {
//               var obj = {};
//               var xhr = new XMLHttpRequest();
//               xhr.open('GET', 'http://35.193.183.71/api?url_string=' + url);
//               xhr.onload = function()
//               {
//                   var resp = JSON.parse(xhr.responseText);
//                   if (resp['Result'] === 'Safe')
//                   {
//                     chrome.browserAction.setIcon({
//                     path : "icon48.png" });
//                   }
//                   else
//                   {
//                      chrome.browserAction.setIcon({
//                       path : "icon248.png"}); 
//                   } 
//                   obj[url] = resp;
//                   // alert(resp);
//                   chrome.storage.sync.set(obj, function(){});
//                   chrome.extension.onConnect.addListener(function(port) {
//                   port.postMessage(resp); });
//               }
//               xhr.send(); 
//            }
//            else
//              {
//                 chrome.storage.sync.get(url , function(data) {
//                   // alert(data[url]['Result']);
//                   chrome.extension.onConnect.addListener(function(port) {
//                   port.postMessage(data[url]); });
//                   // alert(data[url]['Result']);
//                   if (data[url]['Result'] === 'Safe')
//                   {
//                     // alert(1);
//                     chrome.browserAction.setIcon({
//                     path : "icon48.png" });
//                   }
//                   else
//                   {
//                      chrome.browserAction.setIcon({
//                       path : "icon248.png"}); 
//                   } 
//                 });
//              }  
//          });
//        }
// });   

  // chrome.tabs.onActivated.addListener( function(info) {
  //       chrome.storage.sync.get('key' , function(data) {
  //         alert(data.key);
  //        if (typeof data.key === 'undefined') {
  //        chrome.storage.sync.set({'key': 'value'}, function() {
  //                   });
  //        // if already set it then nothing to do 
  //        alert(2);
  //      }
  //       else {
  //       alert(1);
  //     }
      
  //       // chrome.storage.sync.get(['key'], function(result) {
  //       //   alert('Value currently is ' + result.key);
  //       // });
  //     });
  //     });

  // chrome.storage.sync.clear()
      

//  chrome.storage.sync.get(url , function(data) {
//           alert(data[url]);
//           if (typeof data[url] === 'undefined') {
//           var obj = {};
//           obj[url] = resp;
//           chrome.storage.sync.set(obj, function() {
//           // alert('Data saved');
// });
//          // if already set it then nothing to do 
//        }
//         else {
//         alert(1);
//       }
      
//         // chrome.storage.sync.get(['key'], function(result) {
//         //   alert('Value currently is ' + result.key);
//         // });
//       });






















//---------------------------------------------------------------------------------


chrome.tabs.onUpdated.addListener(
  function(tabId, changeInfo, tab) {
    // read changeInfo data and do something with its
    // chrome.storage.sync.get(["disableButton"], function(items){
    //  items = [ { "yourBody": "myBody" } ]
    // alert(items.disableButton);
    if (changeInfo.url) {
      // alert(1);
      chrome.browserAction.setIcon({
            path : "icon148.png" });
      var url = changeInfo.url;
      // alert(changeInfo.url);
      var xhr = new XMLHttpRequest();
      xhr.open('GET', 'https://malicious-webpage-detection.herokuapp.com/api?url_string=' + url);
      xhr.onload = function() {
        resp = JSON.parse(xhr.responseText);
        // alert(resp['Result']);
         if (resp["Result"] === 'Malicious'){
    var notifOptions = {
                        type: "basic",
                        iconUrl: "icon248.png",
                        title: "Result",
                        message: "This Page is Malicious!"
                    };
        chrome.notifications.create('limitNotif', notifOptions);

    }
        if (resp['Result'] === 'Safe')
          {
            chrome.browserAction.setIcon({
            path : "icon48.png" });
          }
          else
          {
             chrome.browserAction.setIcon({
              path : "icon248.png"}); 
          } 
        chrome.extension.onConnect.addListener(function(port) {
           port.postMessage(resp);
      });
          // alert(xhr.responseText);
      };
      xhr.send(); 
    }
  // });
  }
);

chrome.tabs.onActivated.addListener( function(info)
{
    var tab = chrome.tabs.get(info.tabId, function(tab)
    {
      // chrome.storage.sync.get(["disableButton"], function(items){
      if (tab.url)
      {
        // alert(1);
        chrome.browserAction.setIcon({
            path : "icon148.png" });
      var url = tab.url;
      // alert(url);
      var xhr = new XMLHttpRequest();
      xhr.open('GET', 'https://malicious-webpage-detection.herokuapp.com/api?url_string=' + url);
      xhr.onload = function() {
        resp = JSON.parse(xhr.responseText);
        // alert(resp['Result']);
         if (resp["Result"] === 'Malicious'){
    var notifOptions = {
                        type: "basic",
                        iconUrl: "icon248.png",
                        title: "Result",
                        message: "This Page is Malicious!"
                    };
        chrome.notifications.create('limitNotif', notifOptions);

    }
        if (resp['Result'] === 'Safe')
          {
            chrome.browserAction.setIcon({
            path : "icon48.png" });
          }
          else
          {
             chrome.browserAction.setIcon({
              path : "icon248.png"}); 
          } 
        chrome.extension.onConnect.addListener(function(port) {
           port.postMessage(resp);
      });
          // alert(xhr.responseText);
      };
      xhr.send(); 
    }
  // });
  });
 });   

// document.addEventListener('DOMContentLoaded', function() {
//     var tog = document.getElementById('tog');
//     // onClick's logic below:
//     tog.addEventListener('click', function() {
//     	chrome.storage.sync.get(["disableButton"], function(items){
//     //  items = [ { "yourBody": "myBody" } ]
//     if (items.disableButton === '0'){
//     	chrome.storage.sync.set({ "disableButton": "1" }, function(){
// });
//     	$('#togin').text("Enable the Extension");
//     }
//     else{
//     	chrome.storage.sync.set({ "disableButton": "0" }, function(){
// });
//        $('#togin').text("Disable the Extension");
//     }
// });        
//     });
// });

// chrome.tabs.getSelected(null, function(tab){
//    	var tablink = tab.url;
//    	// alert(tablink)
// 	$("#taburl").text(tablink);
// }); 


// chrome.runtime.onMessage.addListener(
//   function(request, sender, sendResponse) {
//     // listen for messages sent from background.js
//     if (request.msg === 'hello') {
//       alert(1); // new url is now in content scripts!
//     }
// });

var port = chrome.extension.connect({
      name: "Sample Communication"
 });
 port.onMessage.addListener(function(msg) {
 	  $('#deep').attr('href', 'https://malicious-webpage-detection.herokuapp.com/?url_string='+msg['URL']);
      // alert("message recieved" + msg['URL']);
		$('#taburl').text("This Webpage is "+msg['Result']+'!');
		$('#guage-textfield').text(Math.round(msg['Malicious Probablity']*100)+'%');
		// $('#taburl').text("Your Webpage is "+msg+'!');
		// $('#guage-textfield').text('10%');
		var opts = {
		  angle: 0.43, // The span of the gauge arc
		  lineWidth: 0.13, // The line thickness
		  radiusScale: 1, // Relative radius
		  pointer: {
		    length: 0.6, // // Relative to gauge radius
		    strokeWidth: 0.035, // The thickness
		    color: '#000000' // Fill color
		  },
		  limitMax: false,     // If false, max value increases automatically if value > maxValue
		  limitMin: false,     // If true, the min value of the gauge will be fixed
		  colorStart: '#ef4b68',   // Colors
		  colorStop: '#ef4b68',    // just experiment with them
		  strokeColor: '#15c375',  // to see which ones work best for you
		  generateGradient: true,
		  highDpiSupport: true,     // High resolution support
		};
		var target = document.getElementById('foo'); // your canvas element
		var gauge = new Donut(target).setOptions(opts); // create sexy gauge!
		gauge.maxValue = 100; // set max gauge value
		gauge.setMinValue(0);  // Prefer setter over gauge.minValue = 0
		gauge.animationSpeed = 50; // set animation speed (32 is default value)


		var x = document.getElementById('guage-textfield').textContent;
		x = parseFloat(x.slice(0,-1));
		gauge.set(x); // set actual value
        
	});
